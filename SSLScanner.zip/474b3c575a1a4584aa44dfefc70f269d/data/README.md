# Data files

cipher-mapping.txt is from [testssl.sh](https://testssl.sh)

common-primes.txt is from [testssl.sh](https://testssl.sh)
